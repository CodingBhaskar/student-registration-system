import React, { useState } from 'react';

function CourseTypeManager() {
  const [courseTypes, setCourseTypes] = useState([]);
  const [newType, setNewType] = useState('');

  const addCourseType = () => {
    if (newType.trim() === '') return;
    setCourseTypes([...courseTypes, newType]);
    setNewType('');
  };

  return (
    <div>
      <h2>Course Types</h2>
      <input
        type="text"
        value={newType}
        onChange={(e) => setNewType(e.target.value)}
        placeholder="Enter course type"
      />
      <button onClick={addCourseType}>Add</button>

      <ul>
        {courseTypes.map((type, index) => (
          <li key={index}>{type}</li>
        ))}
      </ul>
    </div>
  );
}

export default CourseTypeManager;