import React from 'react';
import CourseTypeManager from './CourseTypeManager'; // Import your component

function App() {
  return (
    <div className="App">
      <h1>Student Registration System</h1>
      <CourseTypeManager />
    </div>
  );
}

export default App;
